@echo off
chcp 65001 >nul
cd /d "%~dp0"
title VDD Control - BAT Menu 25.7.23

:: ===== Auto elevate to Admin =====
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Requesting Administrator rights...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

set "DEVCON=%~dp0Dependencies\devcon.exe"
set "VDD_INF=%~dp0SignedDrivers\x86\VDD\MttVDD.inf"
set "VDD_XML_SRC=%~dp0Dependencies\vdd_settings.xml"
set "VDD_HWID=Root\MttVDD"
set "VDD_WILD=*MttVDD*"
set "VAD_INF=%~dp0SignedDrivers\x86\VAD\VirtualAudioDriver.inf"
set "VAD_HWID=ROOT\VirtualAudioDriver"
set "VAD_WILD=*VirtualAudioDriver*"

if not exist "%DEVCON%" (
    echo [ERROR] devcon.exe not found: %DEVCON%
    echo Use pnputil instead ^(built-in Windows^).
    pause
)

:MENU
cls
echo ============================================
echo  VDD Control 25.7.23 - BAT Menu
echo ============================================
echo  1. Install VDD  (Virtual Display)
echo  2. Install VAD  (Virtual Audio)
echo  3. Enable VDD
echo  4. Disable VDD
echo  5. Restart / Reload VDD (apply vdd_settings.xml)
echo  6. Status / Find devices
echo  7. Rescan hardware
echo  8. Uninstall VDD
echo  9. Uninstall VAD
echo  10. Set Monitor Count (1-4)
echo  0. Exit
echo ============================================
set /p CHOICE=Choose [0-10]:

if "%CHOICE%"=="1" goto INSTALL_VDD
if "%CHOICE%"=="2" goto INSTALL_VAD
if "%CHOICE%"=="3" goto ENABLE_VDD
if "%CHOICE%"=="4" goto DISABLE_VDD
if "%CHOICE%"=="5" goto RESTART_VDD
if "%CHOICE%"=="6" goto STATUS
if "%CHOICE%"=="7" goto RESCAN
if "%CHOICE%"=="8" goto UNINSTALL_VDD
if "%CHOICE%"=="9" goto UNINSTALL_VAD
if "%CHOICE%"=="10" goto SET_COUNT
if "%CHOICE%"=="0" exit /b 0
goto MENU

:INSTALL_VDD
echo.
echo --- Copy vdd_settings.xml next to INF before install ---
if exist "%VDD_XML_SRC%" copy /Y "%VDD_XML_SRC%" "%~dp0SignedDrivers\x86\VDD\vdd_settings.xml"
echo --- Install VDD: %VDD_HWID% ---
"%DEVCON%" install "%VDD_INF%" "%VDD_HWID%"
echo.
echo --- Alternative with pnputil if devcon fails: ---
echo pnputil /add-driver "%VDD_INF%" /install
echo.
"%DEVCON%" status "%VDD_WILD%"
pause
goto MENU

:INSTALL_VAD
echo.
echo --- Install VAD: %VAD_HWID% ---
"%DEVCON%" install "%VAD_INF%" "%VAD_HWID%"
echo.
"%DEVCON%" status "%VAD_WILD%"
pause
goto MENU

:ENABLE_VDD
echo.
"%DEVCON%" enable "%VDD_WILD%"
pause
goto MENU

:DISABLE_VDD
echo.
"%DEVCON%" disable "%VDD_WILD%"
pause
goto MENU

:RESTART_VDD
echo.
echo --- Apply settings: copy xml to REAL driver path then restart ---
echo Real path used by driver: C:\VirtualDisplayDriver\vdd_settings.xml
if exist "%VDD_XML_SRC%" (
    copy /Y "%VDD_XML_SRC%" "%~dp0SignedDrivers\x86\VDD\vdd_settings.xml"
    copy /Y "%VDD_XML_SRC%" "C:\VirtualDisplayDriver\vdd_settings.xml"
    if %errorLevel% neq 0 echo [ERROR] Access Denied! Right-click BAT - Run as Administrator.
    copy /Y "%VDD_XML_SRC%" "C:\IddSampleDriver\vdd_settings.xml" 2>nul
)
echo --- Reload: try restart by instance, then HWID, then disable+enable ---
"%DEVCON%" restart "@ROOT\DISPLAY\0000"
"%DEVCON%" restart "%VDD_WILD%"
if %errorLevel% neq 0 (
    echo devcon restart failed, trying disable+enable...
    "%DEVCON%" disable "%VDD_WILD%"
    timeout /t 2 /nobreak >nul
    "%DEVCON%" enable "%VDD_WILD%"
)
pause
goto MENU

:STATUS
echo.
echo ===== VDD =====
"%DEVCON%" find "%VDD_WILD%"
"%DEVCON%" status "%VDD_WILD%"
echo.
echo ===== VAD =====
"%DEVCON%" find "%VAD_WILD%"
"%DEVCON%" status "%VAD_WILD%"
echo.
echo ===== driverfiles VDD =====
"%DEVCON%" driverfiles "%VDD_WILD%"
pause
goto MENU

:RESCAN
echo.
"%DEVCON%" rescan
pause
goto MENU

:UNINSTALL_VDD
echo.
echo WARNING: This will remove the virtual display.
set /p CONFIRM=Type Y to continue:
if /i not "%CONFIRM%"=="Y" goto MENU
"%DEVCON%" remove "%VDD_WILD%"
"%DEVCON%" rescan
pause
goto MENU

:UNINSTALL_VAD
echo.
set /p CONFIRM=Remove Virtual Audio? Type Y to continue:
if /i not "%CONFIRM%"=="Y" goto MENU
"%DEVCON%" remove "%VAD_WILD%"
"%DEVCON%" rescan
pause
goto MENU

:SET_COUNT
echo.
echo Current setting:
echo - Dependencies XML:
powershell -NoProfile -Command "[xml]$x=Get-Content '%VDD_XML_SRC%'; Write-Output ('  monitors/count = ' + $x.vdd_settings.monitors.count)"
echo - REAL driver XML:
powershell -NoProfile -Command "$p='C:\VirtualDisplayDriver\vdd_settings.xml'; if (Test-Path $p) { [xml]$x=Get-Content $p; Write-Output ('  monitors/count = ' + $x.vdd_settings.monitors.count) } else { Write-Output '  NOT FOUND - driver may not be installed'}"
echo.
set /p NUM=Enter monitor count [1-4]:
if "%NUM%"=="" goto MENU
if %NUM% LSS 1 goto MENU
if %NUM% GTR 4 goto MENU
echo Setting count to %NUM%...
powershell -NoProfile -Command "$p='%VDD_XML_SRC%'; [xml]$x=Get-Content $p; $x.vdd_settings.monitors.count='%NUM%'; $x.Save($p); Write-Output ('Saved: ' + $p + ' count=' + $x.vdd_settings.monitors.count)"
copy /Y "%VDD_XML_SRC%" "%~dp0SignedDrivers\x86\VDD\vdd_settings.xml"
copy /Y "%VDD_XML_SRC%" "C:\VirtualDisplayDriver\vdd_settings.xml"
if %errorLevel% neq 0 echo [ERROR] Access Denied! Right-click BAT - Run as Administrator.
copy /Y "%VDD_XML_SRC%" "C:\IddSampleDriver\vdd_settings.xml" 2>nul
echo.
echo --- Reload driver to apply ---
"%DEVCON%" restart "@ROOT\DISPLAY\0000"
"%DEVCON%" restart "%VDD_WILD%"
if %errorLevel% neq 0 (
    "%DEVCON%" disable "%VDD_WILD%"
    timeout /t 2 /nobreak >nul
    "%DEVCON%" enable "%VDD_WILD%"
)
echo.
echo Done. Check Windows Settings - System - Display.
pause
goto MENU
